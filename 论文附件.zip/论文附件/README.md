# 算力约束下提升大语言模型能力的资源配置建模 —— 程序与结果附件

**竞赛**：“华为杯”第二十三届中国研究生数学建模竞赛　**题号**：F 题
**内容**：四问的求解程序、实验产出、稳健性检查结果与论文用图

> 本附件**不含赛题原始数据文件**（体积与数据权属原因）。
> 主流程需要原始数据才能重跑，放置方法见 [§3.3](#33-需要原始数据的程序主流程)。

---

## 1. 提交结果

| 文件 / 目录 | 内容 |
| --- | --- |
| **`四问最终结果汇总.md`** | 四问的核心答案、关键数字与必须随结论一起写的口径限制 |
| **`results/Q1/` ～ `results/Q4/`** | 四问的全部实验产出 |
| ├ `experiments/round*/tables/*.csv` | 结果数据表（域序、参数、验证、敏感性等） |
| ├ `experiments/round*/metrics/*.json` | 方法指标与自助区间 |
| └ `experiments/round*/run_summary.json` | 该问本轮实验的汇总（方法对照与判定） |
| **`robustness/`** | 四问的稳健性检查产出（敏感性、误差与基线对照） |
| **`paper/figures/`** | 论文正文使用的 **18 张图**：`*.pdf` 矢量版（正文用）与 `*.png` 400 dpi 预览版 |
| `workspace/data/`、`workspace/data_clean/` | 数据画像与清洗环节得到的中间产物（下游建模的输入） |
| `requirements.txt` | 运行本附件全部程序所需的 Python 依赖清单 |

四问的最终答案集中在 `四问最终结果汇总.md`，逐条数字均可在上表 `tables/` 与 `metrics/` 中溯源。

---

## 2. AI使用详情

见 **`AI使用说明.md`**。

其中逐条申报了所用人工智能工具的名称、版本/型号、开发机构与版本颁布日期、具体使用范围，
以及人工智能工具输出内容的后续处理策略（含开发框架、开源软件、技术路线、假设条件与参数）。

此外，**每一个程序文件的文件头都带有同样格式的人工智能工具使用声明注释**，
并按“框架逻辑 / 输入格式 / 输出交付”三行概括该程序的输入输出契约。

---

## 3. 程序运行

### 3.1 环境要求

| 项 | 值 |
| --- | --- |
| Python | 3.14.6（3.10 及以上均可） |
| 依赖 | 见 `requirements.txt`，安装：`pip install -r requirements.txt` |
| 操作系统 | Windows / Linux / macOS 均可（仅绘图脚本用到中文字体，见 §3.4） |

`requirements.txt` 记录的版本为本附件实际运行版本：

```
numpy 2.5.1　scipy 1.18.0　pandas 3.0.5　matplotlib 3.11.1
scikit-learn 1.9.0　statsmodels 0.14.6
```

**中文输出**：Windows 控制台默认按 GBK 解码，程序中的中文日志会触发 `UnicodeEncodeError`。
运行前请先设置环境变量：

```bash
# Linux / macOS / Git Bash
export PYTHONIOENCODING=utf-8

# Windows PowerShell
$env:PYTHONIOENCODING="utf-8"
```

**随机性**：全项目随机种子统一为 `20260924`，所有随机数经显式生成器产生。
同输入、同环境重跑应得到相同数值结果。

### 3.2 目录结构

程序的相对路径定位以内层目录为根，请**保持本附件的目录结构不变**后再运行：

```
论文附件/
├── README.md                  ← 本文件
├── AI使用说明.md
├── 四问最终结果汇总.md
├── requirements.txt
├── code/                      ← 四问求解程序
│   ├── figstyle.py                 论文图共享视觉系统
│   ├── paper_framework_figures.py  全篇框架图与四问方法流程图
│   └── Q1/ Q2/ Q3/ Q4/             各问的实现与总控脚本
├── results/                   ← 实验结果产出（Q1～Q4）
├── robustness/                ← 稳健性检查产出
├── paper/figures/             ← 论文用图（18 张 pdf + png）
└── workspace/
    ├── code/scripts/          ← 数据清洗、画像与风险探针脚本
    ├── data/                  ← 数据画像与探针中间产物
    └── data_clean/            ← 清洗后的数据文件
        └── data_raw/          ← 【需自备】赛题原始数据放这里，见 §3.3
```

### 3.3 需要原始数据的程序（主流程）

**以下程序读取赛题原始附件，需自备数据后才能重跑**：

- `code/Q1/run_all.py`（经 `workspace/code/scripts/q1_features.py` 读 A 组数据）
- `code/Q2/run_all.py`（读 B 组数据）
- `code/Q4/run_all.py`、`code/Q4/q4_round2_*.py`（读 C 组数据）
- `workspace/code/scripts/` 下的 `profile_*.py`、`probe_*.py`、`audit_a_missing.py` 等清洗与探针脚本

**放置路径**：请把赛题附件中的三个数据目录原样放到

```
论文附件/workspace/data_raw/real_attachments/
```

放好后该目录下应恰好是：

```
workspace/data_raw/real_attachments/
├── A_data_value/            （RegMix 配比表、SlimPajama 质量信号）
├── B_scaling_laws/          （标度律与训练轨迹）
└── C_efficiency_evolution/  （Open LLM Leaderboard 榜单与逐任务明细）
```

**文件名必须保持原样**，程序按固定文件名读取。目录名也须保持 `A_data_value`、
`B_scaling_laws`、`C_efficiency_evolution` 不变。

> 原始数据合计约 1 GB，含单个超过 100 MB 的文件，因此未随本附件分发。

### 3.4 不需要原始数据的程序（可直接运行）

以下程序只读取本附件内已落盘的结果与中间产物，**开箱即可运行**，也是最快验证本附件完整性的方式。

```bash
# 在“论文附件”目录下执行

# 论文图 18 张（全篇框架图、数据预处理图、四问方法流程图、四问结果图）
python code/paper_framework_figures.py     # 6 张
python code/Q1/q1_paper_figures.py         # 3 张
python code/Q2/q2_paper_figures.py         # 3 张
python code/Q3/q3_paper_figures.py         # 3 张
python code/Q4/q4_paper_figures.py         # 3 张
```

每张图同时输出 `paper/figures/` 下的矢量 `*.pdf`（正文用）与 400 dpi `*.png`（预览用）。

这五个脚本各带一个**出图前对拍**：出图前把手算量与本附件内落盘的结果表逐项核对，
**对拍不过直接报错、拒绝出图**。因此脚本跑通本身就说明图中数字与 `results/` 一致；
脚本内不出现任何手打的结果数字，一律从工件读取。

> 若在无中文字体的环境运行，绘图脚本会回退到默认字体，图形内容不受影响，仅中文字形可能变化。

### 3.5 四问主流程的运行顺序

四问存在数据依赖（**问题三、问题四依赖问题二的结果，问题二、问题三依赖问题一的结果**），
请**按 Q1 → Q2 → Q3 → Q4 的顺序**执行。各问的总控脚本会在本问目录内依次调用本问各方法脚本。

```bash
# 在“论文附件”目录下执行；Q1 与 Q2 带 --run 表示真正重跑
python code/Q1/run_all.py --run     # 逐次执行 M0 → M1 → M0c → M1c，再装配汇总
python code/Q2/run_all.py --run     # 执行 M0s 与 M1s，再装配汇总
python code/Q3/run_all.py           # 执行 M1o 与 M0o
python code/Q4/run_all.py           # 执行 M1a、M0a、桥接与前沿预测
```

`code/Q1/run_all.py` 与 `code/Q2/run_all.py` 去掉 `--run` 时**不重跑计算**，
只从已有的 `metrics/*.json` 重新装配本问的 `run_summary.json`，可在数秒内完成。

各问方法脚本也可单独运行（例如只跑问题一的质量侧主方法）：

```bash
python code/Q1/q1_quality_main.py
python code/Q2/q2_scaling_main.py
python code/Q3/q3_optimize_main.py
```

参考耗时（本机实测，Python 3.14.6 / Windows 11，单机单进程）：

| 程序 | 实测耗时 |
| --- | --- |
| `code/Q1/run_all.py --run` | 约 3 分 10 秒（M0 93 s + M1 92 s + M0c 1 s + M1c 4 s） |
| `code/Q2/run_all.py --run` | 约 7 分 45 秒（M0s 203 s + M1s 260 s） |
| `code/Q3/run_all.py` | 约 3 秒 |
| `code/Q4/run_all.py` | 约 1 分 5 秒 |
| `code/Q1/q1_robustness_*.py` 与 `q1_supplementary_b1_b2.py` | 数分钟（补算项含 40000 次自助，为单项最长） |

问题二耗时明显长于其余三问，因为其非线性最小二乘拟合采用多起点搜索并叠加了自助区间估计。
若只需复核结果而无需重现计算，可直接查看 `results/` 下的既有产出。

### 3.6 结果写回位置

重跑会覆盖对应目录下的既有产出：

| 程序 | 写回位置 |
| --- | --- |
| `code/Q1/run_all.py` | `results/Q1/experiments/round1/` 的 `tables/`、`metrics/`、`figures/`、`run_summary.json` |
| `code/Q1/*_robustness_*.py` | `robustness/Q1/` |
| `code/Q2/run_all.py` | `results/Q2/experiments/round1/` |
| `code/Q3/run_all.py` | `results/Q3/experiments/round1/` |
| `code/Q4/run_all.py` | `results/Q4/experiments/round1/` |
| `code/Q4/q4_round2_*.py` | `results/Q4/experiments/round2/` |
| 五个 `*paper_figures.py` 与 `code/paper_framework_figures.py` | `paper/figures/` |

若重跑失败，`code/Q1/run_all.py` 与 `code/Q2/run_all.py` 会把完整日志写入对应
`results/Qx/experiments/round1/logs/` 目录，便于定位。

---

## 4. 结果如何对照论文

| 论文位置 | 附件中的对应产出 |
| --- | --- |
| 问题一的域序、冲突判据、配比结论 | `results/Q1/.../tables/` 与 `paper/figures/fig_q1_*` |
| 问题二的标度律参数与 `γ` 双路线 | `results/Q2/.../metrics/q2_M1s.json` 与 `fig_q2_*` |
| 问题三的 KKT 最优解与结构性转移 | `results/Q3/.../tables/` 与 `fig_q3_*` |
| 问题四的归因分解与前沿预测 | `results/Q4/.../round1|round2/` 与 `fig_q4_*` |
| 各问的敏感性、稳健性与基线对照 | `robustness/` |
